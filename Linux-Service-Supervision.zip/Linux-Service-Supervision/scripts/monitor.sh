#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

CONFIG_FILE="$PROJECT_DIR/config/services.conf"
LOG_FILE="$PROJECT_DIR/logs/supervisor.log"

while true
do
    echo
    echo "=============================================================="
    echo "              LINUX SERVICE SUPERVISOR"
    echo "=============================================================="
    printf "%-12s %-10s %-8s %-8s %-8s\n" "SERVICE" "STATUS" "PID" "CPU%" "MEM%"
    echo "--------------------------------------------------------------"

    while read -r SERVICE
    do
        [ -z "$SERVICE" ] && continue

        STATUS=$(systemctl is-active "$SERVICE")
        PID=$(systemctl show "$SERVICE" --property=MainPID --value)

        if [ "$PID" != "0" ]; then
            RESOURCE=$(ps -p "$PID" -o %cpu=,%mem=)
            CPU=$(echo "$RESOURCE" | awk '{print $1}')
            MEM=$(echo "$RESOURCE" | awk '{print $2}')
        else
            CPU="N/A"
            MEM="N/A"
        fi

        printf "%-12s %-10s %-8s %-8s %-8s\n" \
            "$SERVICE" "$STATUS" "$PID" "$CPU" "$MEM"

        if [ "$STATUS" != "active" ]; then

            echo "$(date '+%Y-%m-%d %H:%M:%S') - $SERVICE - FAILURE DETECTED" >> "$LOG_FILE"

            echo
            echo "Service $SERVICE is not running."
            echo "Attempting automatic restart..."

            sudo systemctl restart "$SERVICE"

            NEW_STATUS=$(systemctl is-active "$SERVICE")

            if [ "$NEW_STATUS" = "active" ]; then
                echo "$(date '+%Y-%m-%d %H:%M:%S') - $SERVICE - RESTART SUCCESSFUL" >> "$LOG_FILE"
                echo "Service $SERVICE restarted successfully."
            else
                echo "$(date '+%Y-%m-%d %H:%M:%S') - $SERVICE - RESTART FAILED" >> "$LOG_FILE"
                echo "Service $SERVICE restart failed."
            fi
        fi

    done < "$CONFIG_FILE"

    echo "=============================================================="
    echo "Next check in 5 seconds..."
    sleep 5
done
