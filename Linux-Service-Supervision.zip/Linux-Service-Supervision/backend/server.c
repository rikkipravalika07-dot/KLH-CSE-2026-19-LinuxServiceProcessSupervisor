/*
===============================================================
        LINUX SERVICE SUPERVISION - BACKEND
===============================================================

Project:
    Linux Service Supervision

Purpose:
    This backend contains the actual Linux-side implementation
    for monitoring and managing system services.

Frontend:
    The frontend is maintained separately and is NOT connected
    to this backend.

Main Linux concepts used:
    - systemd
    - systemctl
    - journalctl
    - ps
    - Bash
    - fork()
    - execl()
    - waitpid()
    - signals
    - process monitoring
    - automatic restart
    - activity logging

Managed services:
    - cron
    - chrony

===============================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>

#define MAX_SERVICES 20
#define NAME_SIZE 100
#define COMMAND_SIZE 512

#define CONFIG_FILE "config/services.conf"
#define LOG_FILE "logs/supervisor.log"

#define MONITOR_SCRIPT "./scripts/monitor.sh"


/* ============================================================
   SERVICE STRUCTURE
   ============================================================ */

typedef struct
{
    char name[NAME_SIZE];
    char description[NAME_SIZE];

} Service;


/* ============================================================
   REGISTERED SERVICES
   ============================================================ */

Service services[MAX_SERVICES];

int service_count = 0;


/* ============================================================
   MONITOR PROCESS
   ============================================================ */

pid_t monitor_pid = -1;


/* ============================================================
   FUNCTION DECLARATIONS
   ============================================================ */

void load_services(void);

void show_dashboard(void);

void show_services(void);

void start_service(void);

void stop_service(void);

void restart_service(void);

void check_service_status(void);

void show_processes(void);

void show_service_logs(void);

void show_history(void);

void check_failed_services(void);

void start_monitoring(void);

void stop_monitoring(void);

void show_configuration(void);

void add_service_to_config(void);

void remove_service_from_config(void);

void show_system_information(void);

void shutdown_all_services(void);

void controlled_shutdown(void);

void write_log(const char *service, const char *message);

int service_exists(const char *service);

void get_service_status(const char *service);

void print_menu(void);


/* ============================================================
   WRITE ACTIVITY LOG
   ============================================================ */

void write_log(const char *service, const char *message)
{
    FILE *file;

    time_t current_time;
    struct tm *time_info;

    char timestamp[50];

    current_time = time(NULL);

    time_info = localtime(&current_time);

    strftime(
        timestamp,
        sizeof(timestamp),
        "%Y-%m-%d %H:%M:%S",
        time_info
    );

    file = fopen(LOG_FILE, "a");

    if (file == NULL)
    {
        perror("Unable to open supervisor log");
        return;
    }

    fprintf(
        file,
        "%s - %s - %s\n",
        timestamp,
        service,
        message
    );

    fclose(file);
}


/* ============================================================
   CHECK WHETHER SERVICE EXISTS
   ============================================================ */

int service_exists(const char *service)
{
    int i;

    for (i = 0; i < service_count; i++)
    {
        if (strcmp(services[i].name, service) == 0)
        {
            return 1;
        }
    }

    return 0;
}


/* ============================================================
   LOAD SERVICES FROM CONFIGURATION FILE
   ============================================================ */

void load_services(void)
{
    FILE *file;

    char line[256];

    file = fopen(CONFIG_FILE, "r");

    if (file == NULL)
    {
        printf("\nConfiguration file not found.\n");

        printf(
            "Using default services: cron and chrony.\n"
        );

        strcpy(services[0].name, "cron");
        strcpy(
            services[0].description,
            "Task Scheduler"
        );

        strcpy(services[1].name, "chrony");
        strcpy(
            services[1].description,
            "Time Synchronization"
        );

        service_count = 2;

        return;
    }


    while (
        fgets(line, sizeof(line), file)
        != NULL
        &&
        service_count < MAX_SERVICES
    )
    {
        line[strcspn(line, "\n")] = '\0';

        if (strlen(line) == 0)
        {
            continue;
        }

        if (line[0] == '#')
        {
            continue;
        }

        /*
            Configuration format:

            service_name

            Example:

            cron
            chrony
        */

        strcpy(
            services[service_count].name,
            line
        );


        if (strcmp(line, "cron") == 0)
        {
            strcpy(
                services[service_count].description,
                "Task Scheduler"
            );
        }

        else if (strcmp(line, "chrony") == 0)
        {
            strcpy(
                services[service_count].description,
                "Time Synchronization"
            );
        }

        else
        {
            strcpy(
                services[service_count].description,
                "Linux System Service"
            );
        }


        service_count++;
    }


    fclose(file);
}


/* ============================================================
   DASHBOARD
   ============================================================ */

void show_dashboard(void)
{
    int i;

    int running = 0;
    int failed = 0;


    printf("\n");
    printf("============================================================\n");
    printf("                 LINUX SERVICE SUPERVISION\n");
    printf("                         DASHBOARD\n");
    printf("============================================================\n");


    printf("\nTotal Registered Services : %d\n", service_count);


    for (i = 0; i < service_count; i++)
    {
        char command[COMMAND_SIZE];

        snprintf(
            command,
            sizeof(command),
            "systemctl is-active %s 2>/dev/null",
            services[i].name
        );

        FILE *pipe = popen(command, "r");

        if (pipe != NULL)
        {
            char status[50];

            if (fgets(status, sizeof(status), pipe))
            {
                status[strcspn(status, "\n")] = '\0';

                if (strcmp(status, "active") == 0)
                {
                    running++;
                }

                else if (
                    strcmp(status, "failed") == 0
                )
                {
                    failed++;
                }
            }

            pclose(pipe);
        }
    }


    printf("Running Services         : %d\n", running);

    printf("Failed Services          : %d\n", failed);

    printf(
        "Automatic Monitoring     : %s\n",
        monitor_pid > 0 ? "ON" : "OFF"
    );


    printf("\n------------------------------------------------------------\n");

    printf(
        "%-15s %-25s %-12s\n",
        "SERVICE",
        "DESCRIPTION",
        "STATUS"
    );

    printf("------------------------------------------------------------\n");


    for (i = 0; i < service_count; i++)
    {
        char command[COMMAND_SIZE];

        char status[50] = "unknown";

        snprintf(
            command,
            sizeof(command),
            "systemctl is-active %s 2>/dev/null",
            services[i].name
        );


        FILE *pipe = popen(command, "r");


        if (pipe != NULL)
        {
            if (fgets(status, sizeof(status), pipe))
            {
                status[strcspn(status, "\n")] = '\0';
            }

            pclose(pipe);
        }


        printf(
            "%-15s %-25s %-12s\n",
            services[i].name,
            services[i].description,
            status
        );
    }


    printf("============================================================\n");
}


/* ============================================================
   VIEW REGISTERED SERVICES
   ============================================================ */

void show_services(void)
{
    int i;

    printf("\n");
    printf("============================================================\n");
    printf("                    REGISTERED SERVICES\n");
    printf("============================================================\n");


    for (i = 0; i < service_count; i++)
    {
        printf(
            "%d. %-15s - %s\n",
            i + 1,
            services[i].name,
            services[i].description
        );
    }


    printf("============================================================\n");
}


/* ============================================================
   START SERVICE
   ============================================================ */

void start_service(void)
{
    char service[NAME_SIZE];

    printf("\nEnter service name: ");

    scanf("%99s", service);


    if (!service_exists(service))
    {
        printf("\nService is not registered.\n");
        return;
    }


    char command[COMMAND_SIZE];


    snprintf(
        command,
        sizeof(command),
        "sudo systemctl start %s",
        service
    );


    printf(
        "\nStarting service %s...\n",
        service
    );


    int result = system(command);


    if (result == 0)
    {
        printf(
            "Service %s started successfully.\n",
            service
        );

        write_log(
            service,
            "SERVICE STARTED"
        );
    }

    else
    {
        printf(
            "Failed to start %s.\n",
            service
        );

        write_log(
            service,
            "START FAILED"
        );
    }
}


/* ============================================================
   STOP SERVICE
   ============================================================ */

void stop_service(void)
{
    char service[NAME_SIZE];

    printf("\nEnter service name: ");

    scanf("%99s", service);


    if (!service_exists(service))
    {
        printf("\nService is not registered.\n");
        return;
    }


    char command[COMMAND_SIZE];


    snprintf(
        command,
        sizeof(command),
        "sudo systemctl stop %s",
        service
    );


    printf(
        "\nStopping service %s...\n",
        service
    );


    int result = system(command);


    if (result == 0)
    {
        printf(
            "Service %s stopped successfully.\n",
            service
        );

        write_log(
            service,
            "SERVICE STOPPED"
        );
    }

    else
    {
        printf(
            "Failed to stop %s.\n",
            service
        );

        write_log(
            service,
            "STOP FAILED"
        );
    }
}


/* ============================================================
   RESTART SERVICE
   ============================================================ */

void restart_service(void)
{
    char service[NAME_SIZE];

    printf("\nEnter service name: ");

    scanf("%99s", service);


    if (!service_exists(service))
    {
        printf("\nService is not registered.\n");
        return;
    }


    char command[COMMAND_SIZE];


    snprintf(
        command,
        sizeof(command),
        "sudo systemctl restart %s",
        service
    );


    printf(
        "\nRestarting service %s...\n",
        service
    );


    int result = system(command);


    if (result == 0)
    {
        printf(
            "Service %s restarted successfully.\n",
            service
        );

        write_log(
            service,
            "RESTART SUCCESSFUL"
        );
    }

    else
    {
        printf(
            "Failed to restart %s.\n",
            service
        );

        write_log(
            service,
            "RESTART FAILED"
        );
    }
}


/* ============================================================
   CHECK SERVICE STATUS
   ============================================================ */

void check_service_status(void)
{
    char service[NAME_SIZE];

    printf("\nEnter service name: ");

    scanf("%99s", service);


    if (!service_exists(service))
    {
        printf("\nService is not registered.\n");
        return;
    }


    get_service_status(service);
}


/* ============================================================
   GET SERVICE STATUS + PID + CPU + MEMORY
   ============================================================ */

void get_service_status(const char *service)
{
    char command[COMMAND_SIZE];

    char buffer[256];


    printf("\n");
    printf("============================================================\n");
    printf("                 SERVICE STATUS\n");
    printf("============================================================\n");


    printf("Service : %s\n", service);


    /*
        Get systemd service state.
    */

    snprintf(
        command,
        sizeof(command),
        "systemctl is-active %s 2>/dev/null",
        service
    );


    FILE *pipe = popen(command, "r");


    if (pipe != NULL)
    {
        if (fgets(buffer, sizeof(buffer), pipe))
        {
            buffer[strcspn(buffer, "\n")] = '\0';

            printf(
                "Status  : %s\n",
                buffer
            );
        }

        pclose(pipe);
    }


    /*
        Get Main PID.
    */

    snprintf(
        command,
        sizeof(command),
        "systemctl show %s --property=MainPID --value 2>/dev/null",
        service
    );


    pipe = popen(command, "r");


    if (pipe != NULL)
    {
        if (fgets(buffer, sizeof(buffer), pipe))
        {
            buffer[strcspn(buffer, "\n")] = '\0';

            printf(
                "PID     : %s\n",
                buffer
            );
        }

        pclose(pipe);
    }


    /*
        Get CPU and memory using ps.
    */

    snprintf(
        command,
        sizeof(command),
        "PID=$(systemctl show %s --property=MainPID --value 2>/dev/null); "
        "if [ \"$PID\" != \"0\" ]; then "
        "ps -p $PID -o %%cpu=,%%mem=; "
        "else echo 'N/A N/A'; fi",
        service
    );


    pipe = popen(command, "r");


    if (pipe != NULL)
    {
        if (fgets(buffer, sizeof(buffer), pipe))
        {
            printf(
                "CPU / MEM : %s",
                buffer
            );
        }

        pclose(pipe);
    }


    printf("============================================================\n");
}


/* ============================================================
   PROCESS MONITOR
   ============================================================ */

void show_processes(void)
{
    printf("\n");
    printf("============================================================\n");
    printf("                    PROCESS MONITOR\n");
    printf("============================================================\n");


    printf(
        "\nPID       USER       CPU%%     MEM%%     PROCESS\n"
    );


    printf(
        "------------------------------------------------------------\n"
    );


    system(
        "ps -eo pid,user,%cpu,%mem,comm "
        "--sort=-%cpu | head -n 21"
    );


    printf(
        "\nProcess monitoring completed.\n"
    );
}


/* ============================================================
   SERVICE LOGS
   ============================================================ */

void show_service_logs(void)
{
    char service[NAME_SIZE];

    printf("\nEnter service name: ");

    scanf("%99s", service);


    if (!service_exists(service))
    {
        printf("\nService is not registered.\n");
        return;
    }


    printf("\n");
    printf("============================================================\n");
    printf("                    SERVICE LOGS\n");
    printf("============================================================\n");


    printf(
        "\nShowing journalctl logs for %s...\n\n",
        service
    );


    char command[COMMAND_SIZE];


    snprintf(
        command,
        sizeof(command),
        "journalctl -u %s --no-pager -n 15 2>/dev/null",
        service
    );


    system(command);


    printf("\n============================================================\n");
}


/* ============================================================
   VIEW SUPERVISOR HISTORY
   ============================================================ */

void show_history(void)
{
    printf("\n");
    printf("============================================================\n");
    printf("                    SERVICE HISTORY\n");
    printf("============================================================\n");


    FILE *file = fopen(LOG_FILE, "r");


    if (file == NULL)
    {
        printf("\nNo history available.\n");
        return;
    }


    char line[512];


    while (fgets(line, sizeof(line), file))
    {
        printf("%s", line);
    }


    fclose(file);


    printf("\n============================================================\n");
}


/* ============================================================
   CHECK FAILED SERVICES
   ============================================================ */

void check_failed_services(void)
{
    int i;

    int failed_found = 0;


    printf("\n");
    printf("============================================================\n");
    printf("                    FAILURE DETECTION\n");
    printf("============================================================\n");


    for (i = 0; i < service_count; i++)
    {
        char command[COMMAND_SIZE];

        char status[50] = "";


        snprintf(
            command,
            sizeof(command),
            "systemctl is-active %s 2>/dev/null",
            services[i].name
        );


        FILE *pipe = popen(command, "r");


        if (pipe != NULL)
        {
            if (fgets(status, sizeof(status), pipe))
            {
                status[strcspn(status, "\n")] = '\0';
            }

            pclose(pipe);
        }


        if (
            strcmp(status, "active") != 0
        )
        {
            failed_found = 1;


            printf(
                "\n[ALERT] %s is not active.\n",
                services[i].name
            );


            printf(
                "Attempting automatic recovery...\n"
            );


            snprintf(
                command,
                sizeof(command),
                "sudo systemctl restart %s",
                services[i].name
            );


            int result = system(command);


            if (result == 0)
            {
                printf(
                    "Recovery successful for %s.\n",
                    services[i].name
                );


                write_log(
                    services[i].name,
                    "FAILURE DETECTED - RESTART SUCCESSFUL"
                );
            }

            else
            {
                printf(
                    "Recovery failed for %s.\n",
                    services[i].name
                );


                write_log(
                    services[i].name,
                    "FAILURE DETECTED - RESTART FAILED"
                );
            }
        }
    }


    if (!failed_found)
    {
        printf(
            "\nNo failed services detected.\n"
        );
    }


    printf("\n============================================================\n");
}


/* ============================================================
   START AUTOMATIC MONITORING
   ============================================================ */

void start_monitoring(void)
{
    if (monitor_pid > 0)
    {
        printf(
            "\nAutomatic monitoring is already running.\n"
        );

        return;
    }


    printf(
        "\nStarting automatic monitoring...\n"
    );


    /*
        fork() creates a child process.
    */

    monitor_pid = fork();


    if (monitor_pid < 0)
    {
        perror("fork failed");

        monitor_pid = -1;

        return;
    }


    /*
        Child process.
    */

    if (monitor_pid == 0)
    {
        /*
            execl() replaces the child process with
            the Bash monitoring script.
        */

        execl(
            "/bin/bash",
            "bash",
            MONITOR_SCRIPT,
            (char *)NULL
        );


        perror(
            "Failed to execute monitor script"
        );


        exit(EXIT_FAILURE);
    }


    /*
        Parent process.
    */

    printf(
        "Automatic monitoring started.\n"
    );


    printf(
        "Monitor PID: %d\n",
        monitor_pid
    );


    write_log(
        "supervisor",
        "AUTOMATIC MONITORING STARTED"
    );
}


/* ============================================================
   STOP AUTOMATIC MONITORING
   ============================================================ */

void stop_monitoring(void)
{
    if (monitor_pid <= 0)
    {
        printf(
            "\nAutomatic monitoring is not running.\n"
        );

        return;
    }


    printf(
        "\nStopping automatic monitoring...\n"
    );


    /*
        SIGTERM requests controlled termination
        of the monitoring process.
    */

    if (
        kill(
            monitor_pid,
            SIGTERM
        ) == 0
    )
    {
        /*
            waitpid() waits for the child process
            to terminate.
        */

        waitpid(
            monitor_pid,
            NULL,
            0
        );


        printf(
            "Automatic monitoring stopped.\n"
        );


        write_log(
            "supervisor",
            "AUTOMATIC MONITORING STOPPED"
        );


        monitor_pid = -1;
    }

    else
    {
        perror(
            "Unable to stop monitor"
        );

        monitor_pid = -1;
    }
}


/* ============================================================
   SHOW CONFIGURATION
   ============================================================ */

void show_configuration(void)
{
    int i;


    printf("\n");
    printf("============================================================\n");
    printf("                  SERVICE CONFIGURATION\n");
    printf("============================================================\n");


    printf(
        "\nConfiguration file: %s\n\n",
        CONFIG_FILE
    );


    for (i = 0; i < service_count; i++)
    {
        printf(
            "%d. %-15s - %s\n",
            i + 1,
            services[i].name,
            services[i].description
        );
    }


    printf(
        "\nMonitoring interval : 5 seconds\n"
    );

    printf(
        "Automatic restart   : Enabled\n"
    );

    printf(
        "Failure logging     : Enabled\n"
    );

    printf(
        "Log source          : journalctl\n"
    );


    printf("\n============================================================\n");
}


/* ============================================================
   ADD SERVICE
   ============================================================ */

void add_service_to_config(void)
{
    char service[NAME_SIZE];

    FILE *file;


    if (service_count >= MAX_SERVICES)
    {
        printf(
            "\nMaximum service limit reached.\n"
        );

        return;
    }


    printf(
        "\nEnter new service name: "
    );

    scanf(
        "%99s",
        service
    );


    if (service_exists(service))
    {
        printf(
            "\nService already exists.\n"
        );

        return;
    }


    file = fopen(
        CONFIG_FILE,
        "a"
    );


    if (file == NULL)
    {
        perror(
            "Unable to open configuration file"
        );

        return;
    }


    fprintf(
        file,
        "%s\n",
        service
    );


    fclose(file);


    strcpy(
        services[service_count].name,
        service
    );


    strcpy(
        services[service_count].description,
        "Linux System Service"
    );


    service_count++;


    printf(
        "\nService %s added successfully.\n",
        service
    );


    write_log(
        service,
        "SERVICE ADDED TO CONFIGURATION"
    );
}


/* ============================================================
   REMOVE SERVICE
   ============================================================ */

void remove_service_from_config(void)
{
    char service[NAME_SIZE];

    int i;

    int found = 0;


    printf(
        "\nEnter service name to remove: "
    );


    scanf(
        "%99s",
        service
    );


    for (i = 0; i < service_count; i++)
    {
        if (
            strcmp(
                services[i].name,
                service
            ) == 0
        )
        {
            found = 1;


            int j;

            for (
                j = i;
                j < service_count - 1;
                j++
            )
            {
                services[j] =
                    services[j + 1];
            }


            service_count--;

            break;
        }
    }


    if (!found)
    {
        printf(
            "\nService not found.\n"
        );

        return;
    }


    /*
        Rewrite configuration file.
    */

    FILE *file =
        fopen(
            CONFIG_FILE,
            "w"
        );


    if (file != NULL)
    {
        for (i = 0; i < service_count; i++)
        {
            fprintf(
                file,
                "%s\n",
                services[i].name
            );
        }

        fclose(file);
    }


    printf(
        "\nService %s removed.\n",
        service
    );


    write_log(
        service,
        "SERVICE REMOVED FROM CONFIGURATION"
    );
}


/* ============================================================
   SYSTEM INFORMATION
   ============================================================ */

void show_system_information(void)
{
    printf("\n");
    printf("============================================================\n");
    printf("                    SYSTEM INFORMATION\n");
    printf("============================================================\n");


    printf("\nOperating System:\n");

    system(
        "grep PRETTY_NAME /etc/os-release"
    );


    printf("\nKernel:\n");

    system(
        "uname -r"
    );


    printf("\nArchitecture:\n");

    system(
        "uname -m"
    );


    printf("\nHostname:\n");

    system(
        "hostname"
    );


    printf("\nCPU:\n");

    system(
        "lscpu | grep 'Model name' | head -n 1"
    );


    printf("\nMemory:\n");

    system(
        "free -h"
    );


    printf("\nUptime:\n");

    system(
        "uptime"
    );


    printf("\nService Manager:\n");

    printf(
        "systemd\n"
    );


    printf("\nSupervisor:\n");

    printf(
        "Linux Service Supervisor\n"
    );


    printf("\n============================================================\n");
}


/* ============================================================
   SHUTDOWN ALL SERVICES
   ============================================================ */

void shutdown_all_services(void)
{
    int i;


    printf("\n");
    printf("============================================================\n");
    printf("                    CONTROLLED SHUTDOWN\n");
    printf("============================================================\n");


    for (i = 0; i < service_count; i++)
    {
        char command[COMMAND_SIZE];


        snprintf(
            command,
            sizeof(command),
            "sudo systemctl stop %s",
            services[i].name
        );


        printf(
            "\nStopping %s...\n",
            services[i].name
        );


        int result =
            system(command);


        if (result == 0)
        {
            printf(
                "%s stopped successfully.\n",
                services[i].name
            );


            write_log(
                services[i].name,
                "SERVICE STOPPED - CONTROLLED SHUTDOWN"
            );
        }

        else
        {
            printf(
                "Failed to stop %s.\n",
                services[i].name
            );
        }
    }


    printf(
        "\nAll registered services processed.\n"
    );
}


/* ============================================================
   CONTROLLED SUPERVISOR SHUTDOWN
   ============================================================ */

void controlled_shutdown(void)
{
    printf("\n");
    printf("============================================================\n");
    printf("              SHUTTING DOWN SUPERVISOR\n");
    printf("============================================================\n");


    /*
        First stop automatic monitoring.
    */

    if (monitor_pid > 0)
    {
        stop_monitoring();
    }


    /*
        Then stop registered services.
    */

    shutdown_all_services();


    write_log(
        "supervisor",
        "SUPERVISOR SHUTDOWN COMPLETED"
    );


    printf(
        "\nSupervisor shutdown completed.\n"
    );
}


/* ============================================================
   MENU
   ============================================================ */

void print_menu(void)
{
    printf("\n");

    printf("============================================================\n");

    printf(
        "                 LINUX SERVICE SUPERVISOR\n"
    );

    printf("============================================================\n");


    printf(
        " 1. Dashboard\n"
    );

    printf(
        " 2. View Services\n"
    );

    printf(
        " 3. Start Service\n"
    );

    printf(
        " 4. Stop Service\n"
    );

    printf(
        " 5. Restart Service\n"
    );

    printf(
        " 6. Check Service Status\n"
    );

    printf(
        " 7. Process Monitor\n"
    );

    printf(
        " 8. Service Logs\n"
    );

    printf(
        " 9. Service History\n"
    );

    printf(
        "10. Check Failed Services\n"
    );

    printf(
        "11. Start Automatic Monitoring\n"
    );

    printf(
        "12. Stop Automatic Monitoring\n"
    );

    printf(
        "13. View Configuration\n"
    );

    printf(
        "14. Add Service\n"
    );

    printf(
        "15. Remove Service\n"
    );

    printf(
        "16. System Information\n"
    );

    printf(
        "17. Shutdown All Services\n"
    );

    printf(
        "18. Shutdown Supervisor\n"
    );

    printf(
        "19. Exit\n"
    );


    printf(
        "============================================================\n"
    );

    printf(
        "Enter your choice: "
    );
}


/* ============================================================
   MAIN
   ============================================================ */

int main(void)
{
    int choice;


    /*
        Load registered services when backend starts.
    */

    load_services();


    /*
        Main menu loop.
    */

    while (1)
    {
        print_menu();


        if (
            scanf(
                "%d",
                &choice
            ) != 1
        )
        {
            printf(
                "\nInvalid input.\n"
            );

            while (
                getchar() != '\n'
            );

            continue;
        }


        switch (choice)
        {
            case 1:

                show_dashboard();

                break;


            case 2:

                show_services();

                break;


            case 3:

                start_service();

                break;


            case 4:

                stop_service();

                break;


            case 5:

                restart_service();

                break;


            case 6:

                check_service_status();

                break;


            case 7:

                show_processes();

                break;


            case 8:

                show_service_logs();

                break;


            case 9:

                show_history();

                break;


            case 10:

                check_failed_services();

                break;


            case 11:

                start_monitoring();

                break;


            case 12:

                stop_monitoring();

                break;


            case 13:

                show_configuration();

                break;


            case 14:

                add_service_to_config();

                break;


            case 15:

                remove_service_from_config();

                break;


            case 16:

                show_system_information();

                break;


            case 17:

                shutdown_all_services();

                break;


            case 18:

                controlled_shutdown();

                return 0;


            case 19:

                printf(
                    "\nExiting supervisor...\n"
                );


                if (monitor_pid > 0)
                {
                    stop_monitoring();
                }


                return 0;


            default:

                printf(
                    "\nInvalid choice. "
                    "Please select 1-19.\n"
                );
        }
    }


    return 0;
}