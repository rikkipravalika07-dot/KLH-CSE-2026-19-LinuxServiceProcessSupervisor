#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 65536

int valid_name(const char *name) {
    if (!name || !*name) return 0;
    for (int i = 0; name[i]; i++) {
        if (!isalnum((unsigned char)name[i]) &&
            name[i] != '_' && name[i] != '-' &&
            name[i] != '.' && name[i] != '@')
            return 0;
    }
    return 1;
}

int service_exists(const char *name) {
    FILE *f = fopen("config/services.conf", "r");
    if (!f) return 0;

    char line[256];
    int found = 0;

    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strcmp(line, name) == 0) {
            found = 1;
            break;
        }
    }

    fclose(f);
    return found;
}

void send_response(int client, const char *type, const char *body) {
    char header[512];
    int length = snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "Access-Control-Allow-Origin: *\r\n\r\n",
        type, strlen(body));

    send(client, header, length, 0);
    send(client, body, strlen(body), 0);
}

void send_error(int client, int code, const char *message) {
    char body[512], header[512];

    snprintf(body, sizeof(body), "{\"error\":\"%s\"}", message);
    snprintf(header, sizeof(header),
        "HTTP/1.1 %d Error\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n\r\n",
        code, strlen(body));

    send(client, header, strlen(header), 0);
    send(client, body, strlen(body), 0);
}

void get_command_output(const char *command, char *output, size_t size) {
    FILE *p = popen(command, "r");
    if (!p) {
        snprintf(output, size, "unknown");
        return;
    }

    if (!fgets(output, size, p))
        snprintf(output, size, "unknown");

    output[strcspn(output, "\r\n")] = '\0';
    pclose(p);
}

int run_service_command(const char *action, const char *name) {
    const char *allowed[] = {"start", "stop", "restart"};
    int valid_action = 0;

    for (int i = 0; i < 3; i++)
        if (strcmp(action, allowed[i]) == 0)
            valid_action = 1;

    if (!valid_action || !valid_name(name) || !service_exists(name))
        return -1;

    pid_t pid = fork();

    if (pid < 0) return -1;

    if (pid == 0) {
        execl("/usr/bin/sudo", "sudo", "-n",
              "/usr/bin/systemctl", action, name, (char *)NULL);
        _exit(127);
    }

    int status;
    waitpid(pid, &status, 0);

    return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
}

void services_api(int client) {
    FILE *f = fopen("config/services.conf", "r");
    if (!f) {
        send_error(client, 500, "Cannot read services.conf");
        return;
    }

    char result[8192] = "{\"services\":[";
    char line[256], status[128], pid[128], cpu[128], memory[128];
    int first = 1;

    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';

        if (!valid_name(line)) continue;

        char command[512];

        snprintf(command, sizeof(command),
                 "/usr/bin/systemctl is-active %s 2>/dev/null", line);
        get_command_output(command, status, sizeof(status));

        snprintf(command, sizeof(command),
                 "/usr/bin/systemctl show %s -p MainPID --value 2>/dev/null",
                 line);
        get_command_output(command, pid, sizeof(pid));

        snprintf(cpu, sizeof(cpu), "N/A");
        snprintf(memory, sizeof(memory), "N/A");

        if (strcmp(pid, "0") != 0 && strcmp(pid, "unknown") != 0) {
            snprintf(command, sizeof(command),
                     "ps -p %s -o %%cpu= 2>/dev/null", pid);
            get_command_output(command, cpu, sizeof(cpu));

            snprintf(command, sizeof(command),
                     "ps -p %s -o %%mem= 2>/dev/null", pid);
            get_command_output(command, memory, sizeof(memory));
        }

        char item[1024];
        snprintf(item, sizeof(item),
            "%s{\"name\":\"%s\",\"status\":\"%s\","
            "\"pid\":\"%s\",\"cpu\":\"%s\",\"memory\":\"%s\"}",
            first ? "" : ",", line, status, pid, cpu, memory);

        if (strlen(result) + strlen(item) + 3 < sizeof(result))
            strcat(result, item);

        first = 0;
    }

    fclose(f);
    strcat(result, "]}");
    send_response(client, "application/json", result);
}
void processes_api(int client) {
    FILE *fp = popen(
        "ps -eo pid,user,pcpu,pmem,comm --sort=-pcpu | head -n 11",
        "r"
    );

    if (!fp) {
        send_error(client, 500, "Could not read processes");
        return;
    }

    char result[8192] = "{\"processes\":[";
    char line[512];
    int first = 1;

    fgets(line, sizeof(line), fp); // Skip header

    while (fgets(line, sizeof(line), fp)) {
        char pid[32], user[64], cpu[32], memory[32], name[128];

        if (sscanf(line, "%31s %63s %31s %31s %127s",
                   pid, user, cpu, memory, name) != 5)
            continue;

        char item[512];

        snprintf(item, sizeof(item),
            "%s{\"pid\":\"%s\",\"user\":\"%s\","
            "\"cpu\":\"%s\",\"memory\":\"%s\","
            "\"process\":\"%s\",\"status\":\"Running\"}",
            first ? "" : ",", pid, user, cpu, memory, name);

        if (strlen(result) + strlen(item) + 3 < sizeof(result))
            strcat(result, item);

        first = 0;
    }

    pclose(fp);

    strcat(result, "]}");
    send_response(client, "application/json", result);
}
void logs_api(int client, const char *request) {
    char result[16384];
    char command[512];
    char service[32] = "all";

    const char *query = strstr(request, "service=");

    if (query) {
        if (sscanf(query + 8, "%31[^ &]", service) != 1) {
            send_error(client, 400, "Invalid service");
            return;
        }
    }

    if (strcmp(service, "cron") == 0) {
        snprintf(command, sizeof(command),
            "journalctl -u cron.service --no-pager -n 20 2>&1");
    }
    else if (strcmp(service, "chrony") == 0) {
        snprintf(command, sizeof(command),
            "journalctl -u chrony.service --no-pager -n 20 2>&1");
    }
    else if (strcmp(service, "supervisor") == 0) {
        snprintf(command, sizeof(command),
            "tail -n 20 logs/supervisor.log 2>&1");
    }
    else if (strcmp(service, "all") == 0) {
        snprintf(command, sizeof(command),
            "(journalctl -u cron.service --no-pager -n 10; "
            "journalctl -u chrony.service --no-pager -n 10; "
            "tail -n 10 logs/supervisor.log) 2>&1");
    }
    else {
        send_error(client, 400, "Unknown service");
        return;
    }

    FILE *fp = popen(command, "r");

    if (!fp) {
        send_error(client, 500, "Could not read service logs");
        return;
    }

    size_t used = 0;
    char line[512];

    while (fgets(line, sizeof(line), fp)) {
        size_t len = strlen(line);

        if (used + len < sizeof(result) - 1) {
            memcpy(result + used, line, len);
            used += len;
        }
    }

    pclose(fp);
    result[used] = '\0';

    send_response(client, "text/plain", result);
}
void serve_static(int client, const char *path) {
    const char *file = NULL;
    const char *type = "text/plain";

    if (strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0) {
        file = "frontend/index.html";
        type = "text/html";
    } else if (strcmp(path, "/style.css") == 0) {
        file = "frontend/style.css";
        type = "text/css";
    } else if (strcmp(path, "/script.js") == 0) {
        file = "frontend/script.js";
        type = "application/javascript";
    } else {
        send_error(client, 404, "File not found");
        return;
    }

    FILE *f = fopen(file, "rb");
    if (!f) {
        send_error(client, 404, "Frontend file not found");
        return;
    }

    char body[BUFFER_SIZE];
    size_t n = fread(body, 1, sizeof(body) - 1, f);
    body[n] = '\0';
    fclose(f);

    send_response(client, type, body);
}

void handle_request(int client, char *request) {
    char method[16] = "", path[256] = "";

    sscanf(request, "%15s %255s", method, path);

    if (strcmp(method, "GET") == 0 &&
        strcmp(path, "/api/services") == 0) {
        services_api(client);
        return;
    }
if (strcmp(method, "GET") == 0 &&
    strcmp(path, "/api/processes") == 0) {
    processes_api(client);
    return;
}
if (strcmp(method, "GET") == 0 &&
    strncmp(path, "/api/logs", 9) == 0) {
    logs_api(client, request);
    return;
}

    if (strcmp(method, "POST") == 0 &&
        strcmp(path, "/api/service") == 0) {
        char *body = strstr(request, "\r\n\r\n");
        if (!body) {
            send_error(client, 400, "Missing request body");
            return;
        }

        body += 4;

        char action[32] = "", name[128] = "";

        char *a = strstr(body, "\"action\"");
        char *n = strstr(body, "\"name\"");

        if (a) {
            a = strchr(a, ':');
            if (a) sscanf(a + 1, " \"%31[^\"]", action);
        }

        if (n) {
            n = strchr(n, ':');
            if (n) sscanf(n + 1, " \"%127[^\"]", name);
        }

        int result = run_service_command(action, name);

        if (result == 0)
            send_response(client, "application/json",
                          "{\"success\":true}");
        else
            send_error(client, 400,
                       "Action failed or service is not registered");

        return;
    }

    if (strcmp(method, "GET") == 0) {
        serve_static(client, path);
        return;
    }

    send_error(client, 404, "Endpoint not found");
}

int main(void) {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket");
        return 1;
    }

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 10) < 0) {
        perror("listen");
        close(server_fd);
        return 1;
    }

    printf("Linux Service Supervision API running at:\n");
    printf("http://127.0.0.1:%d\n", PORT);
    printf("Press Ctrl+C to stop.\n");

    while (1) {
        int client = accept(server_fd, NULL, NULL);
        if (client < 0) continue;

        char request[BUFFER_SIZE];
        memset(request, 0, sizeof(request));

        ssize_t received = recv(client, request, sizeof(request) - 1, 0);
        if (received > 0)
            handle_request(client, request);

        close(client);
    }

    close(server_fd);
    return 0;
}
