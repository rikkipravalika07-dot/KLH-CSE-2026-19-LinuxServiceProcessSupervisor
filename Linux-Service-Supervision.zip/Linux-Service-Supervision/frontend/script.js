/* =========================================================
   LINUX SERVICE SUPERVISION
   Frontend Demonstration
   =========================================================

   IMPORTANT:
   This frontend is a demonstration/simulation.

   It is intentionally NOT connected to the backend.

   The backend contains the actual Linux/systemd implementation.
*/


/* ================= SERVICE DATA ================= */

let services = {

    cron: {
        name: "cron",
        description: "Task Scheduler",
        status: "active",
        pid: "1390",
        cpu: "0.0%",
        memory: "0.1%",
        uptime: "2h 34m"
    },

    chrony: {
        name: "chrony",
        description: "Time Synchronization",
        status: "active",
        pid: "2584",
        cpu: "0.0%",
        memory: "0.2%",
        uptime: "5h 18m"
    }

};


/* ================= OTHER DATA ================= */

let monitoring = false;

let historyData = [

    {
        time: "10:42:17",
        service: "cron",
        action: "Automatic Restart",
        result: "Success"
    },

    {
        time: "10:41:52",
        service: "cron",
        action: "Failure Detected",
        result: "Recovered"
    },

    {
        time: "09:35:04",
        service: "chrony",
        action: "Restart",
        result: "Success"
    }

];


let alertsData = [

    {
        service: "cron",
        type: "success",
        title: "Service Recovered",
        message: "cron was restarted successfully by the supervisor.",
        time: "Today, 10:42:17"
    },

    {
        service: "chrony",
        type: "success",
        title: "Service Restarted",
        message: "chrony service is running normally.",
        time: "Today, 09:35:04"
    }

];


let activityData = [
    "cron service restarted successfully.",
    "Automatic monitoring checked all registered services.",
    "chrony service status verified.",
    "Supervisor log updated."
];


let processes = [

    {
        pid: "1",
        user: "root",
        cpu: "0.0",
        memory: "0.2",
        process: "systemd",
        status: "Running"
    },

    {
        pid: "1390",
        user: "root",
        cpu: "0.0",
        memory: "0.1",
        process: "cron",
        status: "Running"
    },

    {
        pid: "2584",
        user: "root",
        cpu: "0.0",
        memory: "0.2",
        process: "chronyd",
        status: "Running"
    },

    {
        pid: "930",
        user: "rikki",
        cpu: "0.3",
        memory: "0.4",
        process: "monitor.sh",
        status: "Running"
    },

    {
        pid: "1020",
        user: "root",
        cpu: "0.1",
        memory: "0.3",
        process: "dbus-daemon",
        status: "Running"
    },

    {
        pid: "1105",
        user: "root",
        cpu: "0.2",
        memory: "0.5",
        process: "NetworkManager",
        status: "Running"
    },

    {
        pid: "1210",
        user: "rikki",
        cpu: "0.1",
        memory: "0.2",
        process: "bash",
        status: "Running"
    }

];


/* ================= PAGE NAVIGATION ================= */

function showPage(pageId, button = null) {

    const pages = document.querySelectorAll(".page");

    pages.forEach(page => {
        page.classList.remove("active-page");
    });


    const selectedPage = document.getElementById(pageId);

    if (selectedPage) {
        selectedPage.classList.add("active-page");
    }


    const navItems = document.querySelectorAll(".nav-item");

    navItems.forEach(item => {
        item.classList.remove("active");
    });


    if (button) {
        button.classList.add("active");
    }


    const titles = {

        dashboard: "Dashboard",

        services: "Service Management",

        processes: "Process Monitor",

        logs: "Service Logs",

        history: "Service History",

        alerts: "Alerts",

        configuration: "Configuration",

        system: "System Information"

    };


    document.getElementById("pageTitle").textContent =
        titles[pageId] || "Linux Service Supervisor";


    if (pageId === "dashboard") {
        renderDashboard();
    }

    if (pageId === "services") {
        renderServiceCards();
    }
if (pageId === "processes") {
    loadBackendProcesses();
}

    if (pageId === "logs") {
        changeLogs();
    }

    if (pageId === "history") {
        renderHistory();
    }

    if (pageId === "alerts") {
    loadBackendServices();
}

    if (pageId === "configuration") {
        renderConfiguration();
    }

}


/* ================= DASHBOARD ================= */

function renderDashboard() {

    const serviceArray = Object.values(services);


    document.getElementById("totalServices").textContent =
        serviceArray.length;


    const running = serviceArray.filter(
        service => service.status === "active"
    ).length;


    const failed = serviceArray.filter(
        service => service.status === "failed"
    ).length;


    document.getElementById("runningServices").textContent =
        running;


    document.getElementById("failedServices").textContent =
        failed;


    document.getElementById("monitoringStatus").textContent =
        monitoring ? "ON" : "OFF";


    const table = document.getElementById("dashboardServices");

    table.innerHTML = "";


    serviceArray.forEach(service => {

        const row = document.createElement("tr");


        row.innerHTML = `

            <td>
                <strong>${service.name}</strong>
            </td>

            <td>
                ${service.description}
            </td>

            <td>
                <span class="status ${service.status}">
                    ${service.status}
                </span>
            </td>

            <td>
                ${service.pid}
            </td>

            <td>
                ${service.cpu}
            </td>

            <td>
                ${service.memory}
            </td>

            <td>

                <div class="action-buttons">

                    <button
                        class="small-btn start"
                        onclick="startService('${service.name}')">
                        Start
                    </button>

                    <button
                        class="small-btn stop"
                        onclick="stopService('${service.name}')">
                        Stop
                    </button>

                    <button
                        class="small-btn restart"
                        onclick="restartService('${service.name}')">
                        Restart
                    </button>

                </div>

            </td>

        `;


        table.appendChild(row);

    });


    renderActivity();

}


/* ================= SERVICE CARDS ================= */

function renderServiceCards() {

    const container =
        document.getElementById("serviceCards");


    container.innerHTML = "";


    Object.values(services).forEach(service => {

        const card =
            document.createElement("div");


        card.className = "service-card";


        card.innerHTML = `

            <h3>${service.name}</h3>

            <p>${service.description}</p>

            <span class="status ${service.status}">
                ${service.status}
            </span>

            <div class="service-info">

                <div>
                    <span>PID</span>
                    <strong>${service.pid}</strong>
                </div>

                <div>
                    <span>CPU</span>
                    <strong>${service.cpu}</strong>
                </div>

                <div>
                    <span>Memory</span>
                    <strong>${service.memory}</strong>
                </div>

            </div>

            <div class="action-buttons">

                <button
                    class="small-btn start"
                    onclick="startService('${service.name}')">
                    ▶ Start
                </button>

                <button
                    class="small-btn stop"
                    onclick="stopService('${service.name}')">
                    ■ Stop
                </button>

                <button
                    class="small-btn restart"
                    onclick="restartService('${service.name}')">
                    ↻ Restart
                </button>

                <button
                    class="small-btn logs"
                    onclick="viewServiceLogs('${service.name}')">
                    📜 Logs
                </button>

            </div>

        `;


        container.appendChild(card);

    });

}


/* ================= START SERVICE ================= */

function startService(name) {

    const service = services[name];

    if (!service) {
        return;
    }


    service.status = "active";

    service.pid =
        service.pid === "0"
            ? String(Math.floor(Math.random() * 5000) + 1000)
            : service.pid;


    addHistory(
        name,
        "Start",
        "Success"
    );


    addActivity(
        `${name} service started successfully.`
    );


    showToast(
        `${name} service started`
    );


    refreshCurrentPage();

}


/* ================= STOP SERVICE ================= */

function stopService(name) {

    const service = services[name];

    if (!service) {
        return;
    }


    service.status = "inactive";

    service.pid = "0";

    service.cpu = "N/A";

    service.memory = "N/A";


    addHistory(
        name,
        "Stop",
        "Success"
    );


    addActivity(
        `${name} service stopped.`
    );


    showToast(
        `${name} service stopped`
    );


    refreshCurrentPage();

}


/* ================= RESTART SERVICE ================= */

function restartService(name) {

    const service = services[name];

    if (!service) {
        return;
    }


    service.status = "active";

    service.pid =
        String(
            Math.floor(
                Math.random() * 5000
            ) + 1000
        );


    service.cpu = "0.0%";

    service.memory = "0.1%";


    addHistory(
        name,
        "Restart",
        "Success"
    );


    addActivity(
        `${name} service restarted successfully.`
    );


    alertsData.unshift({

        service: name,

        type: "success",

        title: "Service Restarted",

        message:
            `${name} was restarted successfully.`,

        time:
            "Just now"

    });


    showToast(
        `${name} service restarted`
    );


    refreshCurrentPage();

}


/* ================= VIEW LOGS ================= */

function viewServiceLogs(name) {

    showPage("logs");


    setTimeout(() => {

        document.getElementById("logService").value =
            name;

        changeLogs();

    }, 50);

}


/* ================= MONITORING ================= */

function toggleMonitoring() {

    monitoring = !monitoring;


    const button =
        document.getElementById("monitorButton");


    if (monitoring) {

        button.textContent =
            "Stop Monitoring";

        button.classList.add("active");


        addActivity(
            "Automatic monitoring started."
        );


        showToast(
            "Automatic monitoring started"
        );

    } else {

        button.textContent =
            "Start Monitoring";

        button.classList.remove("active");


        addActivity(
            "Automatic monitoring stopped."
        );


        showToast(
            "Automatic monitoring stopped"
        );

    }


    renderDashboard();

}


/* ================= SHUTDOWN ================= */

function shutdownAll() {

    const confirmShutdown =
        confirm(
            "Shutdown all registered services?"
        );


    if (!confirmShutdown) {
        return;
    }


    Object.values(services).forEach(service => {

        service.status = "inactive";

        service.pid = "0";

        service.cpu = "N/A";

        service.memory = "N/A";

    });


    monitoring = false;


    addActivity(
        "All registered services were stopped."
    );


    addHistory(
        "ALL",
        "Shutdown All",
        "Success"
    );


    showToast(
        "All services stopped"
    );


    renderDashboard();

}


/* ================= PROCESS MONITOR ================= */

function renderProcesses(list = processes) {

    const table =
        document.getElementById("processTable");


    table.innerHTML = "";


    list.forEach(process => {

        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td>${process.pid}</td>

            <td>${process.user}</td>

            <td>${process.cpu}%</td>

            <td>${process.memory}%</td>

            <td>
                <strong>${process.process}</strong>
            </td>

            <td>
                <span class="status active">
                    ${process.status}
                </span>
            </td>

        `;


        table.appendChild(row);

    });

}


/* ================= PROCESS SEARCH ================= */

function filterProcesses() {

    const search =
        document
            .getElementById("processSearch")
            .value
            .toLowerCase();


    const filtered =
        processes.filter(process =>

            process.process
                .toLowerCase()
                .includes(search)

            ||

            process.pid.includes(search)

            ||

            process.user
                .toLowerCase()
                .includes(search)

        );


    renderProcesses(filtered);

}


/* ================= LOGS ================= */

async function changeLogs() {
    const selected = document.getElementById("logService").value;
    const terminal = document.getElementById("logsTerminal");

    terminal.textContent = "Loading real service logs...";

    try {
        const response = await fetch(
            `/api/logs?service=${encodeURIComponent(selected)}`
        );

        if (!response.ok) {
            throw new Error("Could not fetch logs");
        }

        const logs = await response.text();

        terminal.textContent = logs || "No logs available.";
    } catch (error) {
        console.error("Log loading failed:", error);
        terminal.textContent = "Could not load service logs.";
    }
}


/* ================= HISTORY ================= */

function addHistory(
    service,
    action,
    result
) {

    const now =
        new Date().toLocaleTimeString();


    historyData.unshift({

        time: now,

        service: service,

        action: action,

        result: result

    });


    if (historyData.length > 20) {

        historyData.pop();

    }

}


function renderHistory() {

    const table =
        document.getElementById("historyTable");


    table.innerHTML = "";


    historyData.forEach(item => {

        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td>${item.time}</td>

            <td>${item.service}</td>

            <td>${item.action}</td>

            <td>
                <span class="status active">
                    ${item.result}
                </span>
            </td>

        `;


        table.appendChild(row);

    });

}


function clearHistory() {

    historyData = [];


    renderHistory();


    showToast(
        "History cleared"
    );

}


/* ================= ALERTS ================= */

function renderAlerts() {

    const container =
        document.getElementById(
            "alertsContainer"
        );


    container.innerHTML = "";


    if (alertsData.length === 0) {

        container.innerHTML =
            `<div class="panel">
                No alerts available.
            </div>`;

        return;

    }


    alertsData.forEach(alert => {

        const div =
            document.createElement("div");


        div.className =
            `alert ${alert.type}`;


        div.innerHTML = `

            <h4>
                ${alert.title}
            </h4>

            <p>
                ${alert.message}
            </p>

            <div class="alert-time">
                ${alert.service} • ${alert.time}
            </div>

        `;


        container.appendChild(div);

    });

}


function markAlertsRead() {

    alertsData = [];


    renderAlerts();


    showToast(
        "All alerts marked as read"
    );

}


/* ================= CONFIGURATION ================= */

function addService(event) {

    event.preventDefault();


    const name =
        document
            .getElementById("newService")
            .value
            .trim();


    const description =
        document
            .getElementById("newDescription")
            .value
            .trim();


    if (!name) {
        return;
    }


    if (services[name]) {

        showToast(
            "Service already exists"
        );

        return;

    }


    services[name] = {

        name: name,

        description: description,

        status: "inactive",

        pid: "0",

        cpu: "N/A",

        memory: "N/A",

        uptime: "0m"

    };


    document.getElementById("newService").value = "";

    document.getElementById("newDescription").value = "";


    addActivity(
        `${name} was added to registered services.`
    );


    showToast(
        `${name} service added`
    );


    renderConfiguration();

    renderDashboard();

}


function renderConfiguration() {

    const container =
        document.getElementById(
            "configurationServices"
        );


    container.innerHTML = "";


    Object.values(services).forEach(service => {

        const div =
            document.createElement("div");


        div.className =
            "config-service";


        div.innerHTML = `

            <div>

                <strong>
                    ${service.name}
                </strong>

                <span>
                    ${service.description}
                </span>

            </div>

            <button
                class="remove-btn"
                onclick="removeService('${service.name}')">

                Remove

            </button>

        `;


        container.appendChild(div);

    });

}


function removeService(name) {

    if (!services[name]) {
        return;
    }


    delete services[name];


    addActivity(
        `${name} was removed from configuration.`
    );


    showToast(
        `${name} removed`
    );


    renderConfiguration();

    renderDashboard();

}


/* ================= ACTIVITY ================= */

function addActivity(message) {

    activityData.unshift(message);


    if (activityData.length > 8) {

        activityData.pop();

    }


    renderActivity();

}


function renderActivity() {

    const container =
        document.getElementById(
            "recentActivity"
        );


    if (!container) {
        return;
    }


    container.innerHTML = "";


    activityData.slice(0, 6).forEach(
        (activity, index) => {

            const div =
                document.createElement("div");


            div.className =
                "activity";


            div.innerHTML = `

                <strong>
                    ${activity}
                </strong>

                <span>
                    ${index === 0
                        ? "Just now"
                        : "Earlier"}
                </span>

            `;


            container.appendChild(div);

        }
    );

}


/* ================= REFRESH ================= */

async function refreshDashboard() {
    await loadBackendServices();
    await loadBackendProcesses();
    showToast("Dashboard refreshed");
}

function refreshCurrentPage() {

    const activePage =
        document.querySelector(
            ".active-page"
        );


    if (!activePage) {
        return;
    }


    const pageId =
        activePage.id;


    if (pageId === "dashboard") {
        renderDashboard();
    }

    if (pageId === "services") {
        renderServiceCards();
    }

    if (pageId === "processes") {
        renderProcesses();
    }

    if (pageId === "history") {
        renderHistory();
    }

    if (pageId === "alerts") {
        renderAlerts();
    }

    if (pageId === "configuration") {
        renderConfiguration();
    }

}


/* ================= TOAST ================= */

function showToast(message) {

    const toast =
        document.getElementById("toast");


    toast.textContent =
        message;


    toast.classList.add("show");


    setTimeout(() => {

        toast.classList.remove("show");

    }, 2500);

}


/* ================= INITIAL LOAD ================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        renderDashboard();

        renderServiceCards();

        renderProcesses();

        renderHistory();

        renderAlerts();

        renderConfiguration();

        changeLogs();

    }
);
// ===== REAL BACKEND CONNECTION =====

async function loadBackendServices() {
    try {
        const response = await fetch("/api/services");
        if (!response.ok) throw new Error("API request failed");

        const data = await response.json();
        const updatedServices = {};

        data.services.forEach(item => {
            const oldService = services[item.name] || {};

            updatedServices[item.name] = {
                name: item.name,
                description: oldService.description ||
                    (item.name === "cron"
                        ? "Task Scheduler"
                        : item.name === "chrony"
                            ? "Time Synchronization"
                            : "Linux Service"),
                status: item.status === "active"
                    ? "active"
                    : item.status === "failed"
                        ? "failed"
                        : "inactive",
                pid: item.pid,
                cpu: item.cpu.trim() + "%",
                memory: item.memory.trim() + "%",
                uptime: oldService.uptime || "—"
            };
        });

        services = updatedServices;
// Generate alerts from actual backend service status
alertsData = [];

Object.values(updatedServices).forEach(service => {
    if (service.status === "failed" ||
        service.status === "inactive") {

        alertsData.push({
            service: service.name,
            type: "danger",
            title: "Service Down",
            message: `${service.name} is ${service.status}.`,
            time: new Date().toLocaleString()
        });

    }
});

renderAlerts();
        renderDashboard();
        renderServiceCards();

        console.log("Real service information loaded from backend.");
    } catch (error) {
        console.error("Backend connection failed:", error);
        showToast("Could not connect to backend");
    }
}
async function loadBackendProcesses() {
    try {
        const response = await fetch("/api/processes");

        if (!response.ok) {
            throw new Error("Process API request failed");
        }

        const data = await response.json();

        processes = data.processes;

        renderProcesses();

        console.log("Real Linux processes loaded successfully.");

    } catch (error) {
        console.error("Process loading failed:", error);
        showToast("Could not load Linux processes");
    }
}
async function performServiceAction(action, name) {
    try {
        const response = await fetch("/api/service", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                action: action,
                name: name
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.error || "Service action failed");
        }

        showToast(name + " service " + action + " successful");

        await loadBackendServices();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Service action failed");
    }
}

// Replace simulated actions with real backend actions.
window.startService = function(name) {
    performServiceAction("start", name);
};

window.stopService = function(name) {
    performServiceAction("stop", name);
};

window.restartService = function(name) {
    performServiceAction("restart", name);
};

// Load real service status after the existing page initialization.
document.addEventListener("DOMContentLoaded", function() {
    loadBackendServices();
});
