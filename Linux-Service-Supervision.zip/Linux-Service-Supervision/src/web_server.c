#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080

pid_t monitor_pid = -1;


/* =========================================================
   GET SERVICE STATUS
   ========================================================= */

void get_service_status(const char *service,
                        char *status)
{
    char command[200];
    FILE *fp;

    snprintf(command,
             sizeof(command),
             "systemctl is-active %s 2>/dev/null",
             service);

    fp = popen(command, "r");

    if (fp == NULL)
    {
        strcpy(status, "unknown");
        return;
    }

    if (fgets(status, 50, fp) != NULL)
    {
        status[strcspn(status, "\n")] = '\0';
    }
    else
    {
        strcpy(status, "unknown");
    }

    pclose(fp);
}


/* =========================================================
   GET SERVICE RESOURCES
   ========================================================= */

void get_service_resources(const char *service,
                           char *pid,
                           char *cpu,
                           char *memory)
{
    char command[200];
    FILE *fp;

    snprintf(command,
             sizeof(command),
             "PID=$(systemctl show %s --property=MainPID --value); "
             "if [ \"$PID\" != \"0\" ]; then "
             "ps -p \"$PID\" -o pid=,%%cpu=,%%mem=; "
             "fi",
             service);

    fp = popen(command, "r");

    if (fp == NULL)
    {
        strcpy(pid, "N/A");
        strcpy(cpu, "N/A");
        strcpy(memory, "N/A");
        return;
    }

    char line[200];

    if (fgets(line, sizeof(line), fp) != NULL)
    {
        sscanf(line,
               "%49s %49s %49s",
               pid,
               cpu,
               memory);
    }
    else
    {
        strcpy(pid, "N/A");
        strcpy(cpu, "N/A");
        strcpy(memory, "N/A");
    }

    pclose(fp);
}


/* =========================================================
   CONTROL SERVICE
   ========================================================= */

void control_service(const char *service,
                     const char *action)
{
    if ((strcmp(service, "cron") != 0) &&
        (strcmp(service, "chrony") != 0))
    {
        return;
    }

    if ((strcmp(action, "start") != 0) &&
        (strcmp(action, "stop") != 0) &&
        (strcmp(action, "restart") != 0))
    {
        return;
    }

    char command[200];

    snprintf(command,
             sizeof(command),
             "sudo systemctl %s %s",
             action,
             service);

    system(command);
}


/* =========================================================
   GET SERVICE LOGS
   ========================================================= */

void get_service_logs(const char *service,
                      char *logs,
                      size_t logs_size)
{
    if ((strcmp(service, "cron") != 0) &&
        (strcmp(service, "chrony") != 0))
    {
        snprintf(logs,
                 logs_size,
                 "Invalid service.");
        return;
    }

    char command[200];

    snprintf(command,
             sizeof(command),
             "journalctl -u %s --no-pager -n 10 2>/dev/null",
             service);

    FILE *fp = popen(command, "r");

    if (fp == NULL)
    {
        snprintf(logs,
                 logs_size,
                 "Unable to read logs.");
        return;
    }

    logs[0] = '\0';

    char line[300];

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        if (strlen(logs) +
            strlen(line) + 1 <
            logs_size)
        {
            strcat(logs, line);
        }
    }

    pclose(fp);
}


/* =========================================================
   START AUTOMATIC MONITORING
   ========================================================= */

void start_monitoring()
{
    if (monitor_pid > 0)
    {
        return;
    }

    monitor_pid = fork();

    if (monitor_pid == 0)
    {
        execl("./scripts/monitor.sh",
              "monitor.sh",
              (char *)NULL);

        perror("Failed to start monitor");
        exit(1);
    }
}


/* =========================================================
   STOP AUTOMATIC MONITORING
   ========================================================= */

void stop_monitoring()
{
    if (monitor_pid > 0)
    {
        kill(monitor_pid, SIGTERM);

        waitpid(monitor_pid,
                NULL,
                0);

        monitor_pid = -1;
    }
}


/* =========================================================
   CHECK MONITORING STATUS
   ========================================================= */

int is_monitoring()
{
    if (monitor_pid > 0)
    {
        if (kill(monitor_pid, 0) == 0)
        {
            return 1;
        }

        monitor_pid = -1;
    }

    return 0;
}


/* =========================================================
   SYSTEM INFORMATION
   ========================================================= */

void get_system_information(char *os,
                            char *kernel,
                            char *architecture,
                            char *hostname,
                            char *cpu,
                            char *memory,
                            char *uptime)
{
    FILE *fp;

    strcpy(os, "Linux");


    /* KERNEL */

    fp = popen("uname -r", "r");

    if (fp != NULL)
    {
        fgets(kernel, 100, fp);

        kernel[strcspn(kernel, "\n")] = '\0';

        pclose(fp);
    }


    /* ARCHITECTURE */

    fp = popen("uname -m", "r");

    if (fp != NULL)
    {
        fgets(architecture, 100, fp);

        architecture[strcspn(architecture, "\n")] = '\0';

        pclose(fp);
    }


    /* HOSTNAME */

    gethostname(hostname, 100);

    hostname[99] = '\0';


    /* CPU */

    fp = popen(
        "lscpu | grep 'Model name' | cut -d: -f2-",
        "r"
    );

    if (fp != NULL)
    {
        fgets(cpu, 200, fp);

        cpu[strcspn(cpu, "\n")] = '\0';

        while (cpu[0] == ' ')
        {
            memmove(cpu,
                    cpu + 1,
                    strlen(cpu));
        }

        pclose(fp);
    }


    /* MEMORY */

    fp = popen(
        "free -h | awk '/Mem:/ {print $3 \" used / \" $2 \" total\"}'",
        "r"
    );

    if (fp != NULL)
    {
        fgets(memory, 100, fp);

        memory[strcspn(memory, "\n")] = '\0';

        pclose(fp);
    }


    /* UPTIME */

    fp = popen(
        "uptime -p",
        "r"
    );

    if (fp != NULL)
    {
        fgets(uptime, 200, fp);

        uptime[strcspn(uptime, "\n")] = '\0';

        pclose(fp);
    }
}


/* =========================================================
   COUNT FAILED SERVICES
   ========================================================= */

int count_failed_services()
{
    char services[2][50] =
    {
        "cron",
        "chrony"
    };

    int failed = 0;

    for (int i = 0; i < 2; i++)
    {
        char status[50];

        get_service_status(
            services[i],
            status
        );

        if (strcmp(status, "active") != 0)
        {
            failed++;
        }
    }

    return failed;
}


/* =========================================================
   COUNT RUNNING SERVICES
   ========================================================= */

int count_running_services()
{
    char services[2][50] =
    {
        "cron",
        "chrony"
    };

    int running = 0;

    for (int i = 0; i < 2; i++)
    {
        char status[50];

        get_service_status(
            services[i],
            status
        );

        if (strcmp(status, "active") == 0)
        {
            running++;
        }
    }

    return running;
}


/* =========================================================
   SHUTDOWN ALL SERVICES
   ========================================================= */

void shutdown_all_services()
{
    char *services[] =
    {
        "cron",
        "chrony"
    };

    /* Stop automatic monitoring first */

    if (is_monitoring())
    {
        stop_monitoring();
    }


    /* Stop all services */

    for (int i = 0; i < 2; i++)
    {
        char command[100];

        snprintf(
            command,
            sizeof(command),
            "sudo systemctl stop %s",
            services[i]
        );

        system(command);
    }
}


/* =========================================================
   GET SERVICE HISTORY
   ========================================================= */

void get_service_history(char *history,
                         size_t history_size)
{
    FILE *fp;

    fp = fopen(
        "logs/supervisor.log",
        "r"
    );

    if (fp == NULL)
    {
        snprintf(
            history,
            history_size,
            "No service history available."
        );

        return;
    }

    history[0] = '\0';

    char line[500];

    while (fgets(line,
                 sizeof(line),
                 fp) != NULL)
    {
        if (strlen(history) +
            strlen(line) + 1 <
            history_size)
        {
            strcat(history, line);
        }
    }

    fclose(fp);

    if (strlen(history) == 0)
    {
        snprintf(
            history,
            history_size,
            "No service history available."
        );
    }
}


/* =========================================================
   SEND SERVICE HISTORY PAGE
   ========================================================= */

void send_history_page(int client_fd)
{
    char history[12000];

    get_service_history(
        history,
        sizeof(history)
    );


    int total_services = 2;

    int running_services =
        count_running_services();

    int failed_services =
        count_failed_services();

    const char *monitor_status =
        is_monitoring()
        ? "RUNNING"
        : "STOPPED";


    char response[20000];

    snprintf(
        response,
        sizeof(response),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "\r\n"

        "<html>"

        "<head>"

        "<title>Service History</title>"

        "<style>"

        "body{"
        "font-family:Arial;"
        "background:#f4f6f8;"
        "padding:30px;"
        "}"

        ".summary{"
        "display:grid;"
        "grid-template-columns:repeat(4,1fr);"
        "gap:15px;"
        "max-width:1100px;"
        "margin:0 auto 20px auto;"
        "}"

        ".summary-card{"
        "background:white;"
        "padding:20px;"
        "border-radius:10px;"
        "text-align:center;"
        "box-shadow:0 4px 12px rgba(0,0,0,0.08);"
        "}"

        ".summary-card h3{"
        "margin:0;"
        "color:#555;"
        "}"

        ".summary-card p{"
        "font-size:25px;"
        "font-weight:bold;"
        "margin:10px 0 0;"
        "}"

        ".box{"
        "background:white;"
        "padding:30px;"
        "border-radius:12px;"
        "max-width:1100px;"
        "margin:auto;"
        "box-shadow:0 4px 15px rgba(0,0,0,0.1);"
        "}"

        "h1{"
        "color:#222;"
        "}"

        "pre{"
        "background:#111;"
        "color:#00ff88;"
        "padding:20px;"
        "border-radius:8px;"
        "overflow:auto;"
        "white-space:pre-wrap;"
        "line-height:1.6;"
        "}"

        ".back{"
        "display:inline-block;"
        "margin-top:20px;"
        "padding:10px 20px;"
        "background:#333;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        "</style>"

        "</head>"

        "<body>"


        "<div class='summary'>"

        "<div class='summary-card'>"
        "<h3>Total Services</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Running</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Failed</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Monitoring</h3>"
        "<p>%s</p>"
        "</div>"

        "</div>"


        "<div class='box'>"

        "<h1>Service History</h1>"

        "<p>"
        "Recorded service monitoring and recovery events."
        "</p>"

        "<pre>%s</pre>"

        "<a class='back' href='/'>"
        "← Back to Dashboard"
        "</a>"

        "</div>"

        "</body>"

        "</html>",

        total_services,
        running_services,
        failed_services,
        monitor_status,
        history
    );


    write(
        client_fd,
        response,
        strlen(response)
    );
}


/* =========================================================
   SEND FAILED SERVICES PAGE
   ========================================================= */

void send_failed_page(int client_fd)
{
    char cron_status[50];
    char chrony_status[50];


    get_service_status(
        "cron",
        cron_status
    );

    get_service_status(
        "chrony",
        chrony_status
    );


    int failed =
        count_failed_services();


    char response[10000];

    snprintf(
        response,
        sizeof(response),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "\r\n"

        "<html>"

        "<head>"

        "<title>Failed Services</title>"

        "<style>"

        "body{"
        "font-family:Arial;"
        "background:#f4f6f8;"
        "padding:40px;"
        "}"

        ".box{"
        "background:white;"
        "padding:30px;"
        "border-radius:12px;"
        "max-width:700px;"
        "margin:auto;"
        "box-shadow:0 4px 15px rgba(0,0,0,0.1);"
        "}"

        ".service{"
        "padding:15px;"
        "margin:10px 0;"
        "background:#f1f1f1;"
        "border-radius:8px;"
        "}"

        ".back{"
        "display:inline-block;"
        "margin-top:20px;"
        "padding:10px 20px;"
        "background:#333;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        "</style>"

        "</head>"

        "<body>"

        "<div class='box'>"

        "<h1>Check Failed Services</h1>"

        "<h2>Failed Services: %d</h2>"

        "<div class='service'>"
        "<b>cron</b> — %s"
        "</div>"

        "<div class='service'>"
        "<b>chrony</b> — %s"
        "</div>"

        "<a class='back' href='/'>"
        "← Back to Dashboard"
        "</a>"

        "</div>"

        "</body>"

        "</html>",

        failed,
        cron_status,
        chrony_status
    );


    write(
        client_fd,
        response,
        strlen(response)
    );
}


/* =========================================================
   SEND SYSTEM INFORMATION PAGE
   ========================================================= */

void send_system_page(int client_fd)
{
    char os[100];
    char kernel[100];
    char architecture[100];
    char hostname[100];
    char cpu[200];
    char memory[100];
    char uptime[200];


    get_system_information(
        os,
        kernel,
        architecture,
        hostname,
        cpu,
        memory,
        uptime
    );


    char response[12000];

    snprintf(
        response,
        sizeof(response),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "\r\n"

        "<html>"

        "<head>"

        "<title>System Information</title>"

        "<style>"

        "body{"
        "font-family:Arial;"
        "background:#f4f6f8;"
        "padding:40px;"
        "}"

        ".box{"
        "background:white;"
        "padding:30px;"
        "border-radius:12px;"
        "max-width:800px;"
        "margin:auto;"
        "box-shadow:0 4px 15px rgba(0,0,0,0.1);"
        "}"

        ".info{"
        "padding:15px;"
        "margin:10px 0;"
        "background:#f1f1f1;"
        "border-radius:8px;"
        "}"

        ".back{"
        "display:inline-block;"
        "margin-top:20px;"
        "padding:10px 20px;"
        "background:#333;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        "</style>"

        "</head>"

        "<body>"

        "<div class='box'>"

        "<h1>System Information</h1>"

        "<div class='info'>"
        "<b>Operating System:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>Kernel Version:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>Architecture:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>Hostname:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>CPU:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>Memory:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>Uptime:</b> %s"
        "</div>"

        "<a class='back' href='/'>"
        "← Back to Dashboard"
        "</a>"

        "</div>"

        "</body>"

        "</html>",

        os,
        kernel,
        architecture,
        hostname,
        cpu,
        memory,
        uptime
    );


    write(
        client_fd,
        response,
        strlen(response)
    );
}


/* =========================================================
   SEND LOG PAGE
   ========================================================= */

void send_logs_page(int client_fd,
                    const char *service)
{
    char logs[8000];


    get_service_logs(
        service,
        logs,
        sizeof(logs)
    );


    char response[12000];

    snprintf(
        response,
        sizeof(response),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "\r\n"

        "<html>"

        "<head>"

        "<title>Service Logs</title>"

        "<style>"

        "body{"
        "font-family:Arial;"
        "background:#f4f6f8;"
        "padding:30px;"
        "}"

        ".box{"
        "background:white;"
        "padding:25px;"
        "border-radius:12px;"
        "max-width:1100px;"
        "margin:auto;"
        "}"

        "pre{"
        "background:#111;"
        "color:#00ff88;"
        "padding:20px;"
        "border-radius:8px;"
        "overflow:auto;"
        "white-space:pre-wrap;"
        "}"

        ".back{"
        "display:inline-block;"
        "margin-top:20px;"
        "padding:10px 20px;"
        "background:#333;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        "</style>"

        "</head>"

        "<body>"

        "<div class='box'>"

        "<h1>%s Service Logs</h1>"

        "<pre>%s</pre>"

        "<a class='back' href='/'>"
        "← Back to Dashboard"
        "</a>"

        "</div>"

        "</body>"

        "</html>",

        service,
        logs
    );


    write(
        client_fd,
        response,
        strlen(response)
    );
}


/* =========================================================
   SEND DASHBOARD
   ========================================================= */

void send_dashboard(int client_fd)
{
    int total_services = 2;

    int running_services =
        count_running_services();

    int failed_services =
        count_failed_services();

    const char *monitor_status =
        is_monitoring()
        ? "RUNNING"
        : "STOPPED";


    char cron_status[50];
    char chrony_status[50];


    char cron_pid[50];
    char cron_cpu[50];
    char cron_memory[50];


    char chrony_pid[50];
    char chrony_cpu[50];
    char chrony_memory[50];


    get_service_status(
        "cron",
        cron_status
    );

    get_service_status(
        "chrony",
        chrony_status
    );


    get_service_resources(
        "cron",
        cron_pid,
        cron_cpu,
        cron_memory
    );

    get_service_resources(
        "chrony",
        chrony_pid,
        chrony_cpu,
        chrony_memory
    );


    char response[26000];


    snprintf(
        response,
        sizeof(response),

        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "\r\n"

        "<html>"

        "<head>"

        "<meta http-equiv='refresh' content='5'>"

        "<title>Linux Service Supervisor</title>"


        "<style>"

        "body{"
        "font-family:Arial;"
        "margin:0;"
        "background:#f4f6f8;"
        "}"

        ".header{"
        "background:#222;"
        "color:white;"
        "padding:25px;"
        "text-align:center;"
        "}"

        ".container{"
        "max-width:1100px;"
        "margin:30px auto;"
        "padding:20px;"
        "}"

        ".nav{"
        "background:white;"
        "padding:15px;"
        "border-radius:10px;"
        "margin-bottom:20px;"
        "}"

        ".nav a{"
        "margin-right:15px;"
        "text-decoration:none;"
        "color:#333;"
        "font-weight:bold;"
        "}"

        ".summary{"
        "display:grid;"
        "grid-template-columns:repeat(4,1fr);"
        "gap:15px;"
        "margin-bottom:20px;"
        "}"

        ".summary-card{"
        "background:white;"
        "padding:20px;"
        "border-radius:10px;"
        "text-align:center;"
        "box-shadow:0 4px 12px rgba(0,0,0,0.08);"
        "}"

        ".summary-card h3{"
        "margin:0;"
        "color:#555;"
        "}"

        ".summary-card p{"
        "font-size:25px;"
        "font-weight:bold;"
        "margin:10px 0 0;"
        "}"

        ".grid{"
        "display:grid;"
        "grid-template-columns:repeat(auto-fit,minmax(400px,1fr));"
        "gap:20px;"
        "}"

        ".card{"
        "background:white;"
        "padding:25px;"
        "border-radius:12px;"
        "box-shadow:0 4px 12px rgba(0,0,0,0.08);"
        "}"

        ".status{"
        "font-size:20px;"
        "font-weight:bold;"
        "margin-bottom:15px;"
        "}"

        ".info{"
        "margin:8px 0;"
        "}"

        "button{"
        "padding:10px 15px;"
        "margin:5px;"
        "border:none;"
        "border-radius:6px;"
        "cursor:pointer;"
        "}"

        ".start{"
        "background:#28a745;"
        "color:white;"
        "}"

        ".stop{"
        "background:#dc3545;"
        "color:white;"
        "}"

        ".restart{"
        "background:#007bff;"
        "color:white;"
        "}"

        ".logs-button{"
        "display:inline-block;"
        "padding:10px 15px;"
        "margin-top:10px;"
        "background:#555;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        ".monitor{"
        "background:#fff;"
        "padding:20px;"
        "border-radius:12px;"
        "margin-top:20px;"
        "}"

        ".monitor a{"
        "display:inline-block;"
        "padding:12px 18px;"
        "margin:5px;"
        "background:#6f42c1;"
        "color:white;"
        "text-decoration:none;"
        "border-radius:6px;"
        "}"

        ".shutdown{"
        "background:#8b0000 !important;"
        "}"

        "</style>"

        "</head>"


        "<body>"


        "<div class='header'>"

        "<h1>Linux Service Supervisor</h1>"

        "<p>"
        "Web-Based Linux Service Monitoring and Management"
        "</p>"

        "</div>"


        "<div class='container'>"


        /* NAVIGATION */

        "<div class='nav'>"

        "<a href='/'>"
        "Dashboard"
        "</a>"

        "<a href='/?system=info'>"
        "System Information"
        "</a>"

        "<a href='/?failed=check'>"
        "Check Failed Services"
        "</a>"

        "<a href='/?history=view'>"
        "Service History"
        "</a>"

        "</div>"


        /* SUMMARY */

        "<div class='summary'>"

        "<div class='summary-card'>"
        "<h3>Total Services</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Running</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Failed</h3>"
        "<p>%d</p>"
        "</div>"

        "<div class='summary-card'>"
        "<h3>Monitoring</h3>"
        "<p>%s</p>"
        "</div>"

        "</div>"


        /* SERVICE GRID */

        "<div class='grid'>"


        /* CRON */

        "<div class='card'>"

        "<h2>cron</h2>"

        "<div class='status'>"
        "Status: %s"
        "</div>"

        "<div class='info'>"
        "<b>PID:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>CPU:</b> %s %%"
        "</div>"

        "<div class='info'>"
        "<b>Memory:</b> %s %%"
        "</div>"


        "<form action='/' method='get'>"

        "<input type='hidden' "
        "name='service' value='cron'>"

        "<button class='start' "
        "name='action' value='start'>"
        "Start"
        "</button>"

        "<button class='stop' "
        "name='action' value='stop'>"
        "Stop"
        "</button>"

        "<button class='restart' "
        "name='action' value='restart'>"
        "Restart"
        "</button>"

        "</form>"


        "<a class='logs-button' "
        "href='/?logs=cron'>"
        "View Logs"
        "</a>"

        "</div>"


        /* CHRONY */

        "<div class='card'>"

        "<h2>chrony</h2>"

        "<div class='status'>"
        "Status: %s"
        "</div>"

        "<div class='info'>"
        "<b>PID:</b> %s"
        "</div>"

        "<div class='info'>"
        "<b>CPU:</b> %s %%"
        "</div>"

        "<div class='info'>"
        "<b>Memory:</b> %s %%"
        "</div>"


        "<form action='/' method='get'>"

        "<input type='hidden' "
        "name='service' value='chrony'>"

        "<button class='start' "
        "name='action' value='start'>"
        "Start"
        "</button>"

        "<button class='stop' "
        "name='action' value='stop'>"
        "Stop"
        "</button>"

        "<button class='restart' "
        "name='action' value='restart'>"
        "Restart"
        "</button>"

        "</form>"


        "<a class='logs-button' "
        "href='/?logs=chrony'>"
        "View Logs"
        "</a>"

        "</div>"


        "</div>"


        /* AUTOMATIC MONITORING */

        "<div class='monitor'>"

        "<h2>Automatic Monitoring</h2>"

        "<p>"
        "Monitoring Status: <b>%s</b>"
        "</p>"

        "<a href='/?monitor=start'>"
        "Start Automatic Monitoring"
        "</a>"

        "<a href='/?monitor=stop'>"
        "Stop Automatic Monitoring"
        "</a>"

        "</div>"


        /* SERVICE MANAGEMENT */

        "<div class='monitor'>"

        "<h2>Service Management</h2>"

        "<p>"
        "Stop all monitored services at once."
        "</p>"

        "<a class='shutdown' "
        "href='/?shutdown=all'>"
        "Shutdown All Services"
        "</a>"

        "</div>"


        "</div>"


        "</body>"

        "</html>",


        total_services,
        running_services,
        failed_services,
        monitor_status,

        cron_status,
        cron_pid,
        cron_cpu,
        cron_memory,

        chrony_status,
        chrony_pid,
        chrony_cpu,
        chrony_memory,

        monitor_status    );


    write(
        client_fd,
        response,
        strlen(response)
    );
}


/* =========================================================
   MAIN
   ========================================================= */

int main()
{
    int server_fd;
    int client_fd;

    struct sockaddr_in server_addr;

    char request[4096];


    /* CREATE SOCKET */

    server_fd = socket(
        AF_INET,
        SOCK_STREAM,
        0
    );

    if (server_fd < 0)
    {
        perror("Socket creation failed");
        return 1;
    }


    /* REUSE ADDRESS */

    int opt = 1;

    setsockopt(
        server_fd,
        SOL_SOCKET,
        SO_REUSEADDR,
        &opt,
        sizeof(opt)
    );


    /* SERVER ADDRESS */

    server_addr.sin_family =
        AF_INET;

    server_addr.sin_addr.s_addr =
        INADDR_ANY;

    server_addr.sin_port =
        htons(PORT);


    /* BIND */

    if (bind(
            server_fd,
            (struct sockaddr *)&server_addr,
            sizeof(server_addr)
        ) < 0)
    {
        perror("Bind failed");

        close(server_fd);

        return 1;
    }


    /* LISTEN */

    if (listen(
            server_fd,
            10
        ) < 0)
    {
        perror("Listen failed");

        close(server_fd);

        return 1;
    }


    printf(
        "\n==============================================\n"
        "      LINUX SERVICE SUPERVISOR WEB SERVER\n"
        "==============================================\n"
        "Server running on port %d\n"
        "Open: http://localhost:%d\n"
        "==============================================\n",
        PORT,
        PORT
    );


    /* MAIN SERVER LOOP */

    while (1)
    {
        client_fd = accept(
            server_fd,
            NULL,
            NULL
        );

        if (client_fd < 0)
        {
            perror("Accept failed");
            continue;
        }


        memset(
            request,
            0,
            sizeof(request)
        );


        read(
            client_fd,
            request,
            sizeof(request) - 1
        );


        /* =================================================
           SYSTEM INFORMATION
           ================================================= */

        if (strstr(
                request,
                "GET /?system=info"
            ) != NULL)
        {
            send_system_page(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           FAILED SERVICES
           ================================================= */

        if (strstr(
                request,
                "GET /?failed=check"
            ) != NULL)
        {
            send_failed_page(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           SERVICE HISTORY
           ================================================= */

        if (strstr(
                request,
                "GET /?history=view"
            ) != NULL)
        {
            send_history_page(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           SERVICE LOGS
           ================================================= */

        char log_service[50];

        memset(
            log_service,
            0,
            sizeof(log_service)
        );


        if (sscanf(
                request,
                "GET /?logs=%49[^ ]",
                log_service
            ) == 1)
        {
            send_logs_page(
                client_fd,
                log_service
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           START MONITOR
           ================================================= */

        if (strstr(
                request,
                "GET /?monitor=start"
            ) != NULL)
        {
            start_monitoring();

            send_dashboard(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           STOP MONITOR
           ================================================= */

        if (strstr(
                request,
                "GET /?monitor=stop"
            ) != NULL)
        {
            stop_monitoring();

            send_dashboard(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           SHUTDOWN ALL
           ================================================= */

        if (strstr(
                request,
                "GET /?shutdown=all"
            ) != NULL)
        {
            shutdown_all_services();

            send_dashboard(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           SERVICE CONTROL
           ================================================= */

        char service[50];
        char action[50];


        memset(
            service,
            0,
            sizeof(service)
        );

        memset(
            action,
            0,
            sizeof(action)
        );


        if (sscanf(
                request,
                "GET /?service=%49[^&]&action=%49[^ ]",
                service,
                action
            ) == 2)
        {
            control_service(
                service,
                action
            );

            send_dashboard(
                client_fd
            );

            close(client_fd);

            continue;
        }


        /* =================================================
           DEFAULT DASHBOARD
           ================================================= */

        send_dashboard(
            client_fd
        );

        close(client_fd);
    }


    close(server_fd);

    return 0;
}
