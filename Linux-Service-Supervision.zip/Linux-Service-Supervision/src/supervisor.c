#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

#define CONFIG_FILE "config/services.conf"

pid_t monitor_pid = -1;


/* =================================================
   OPTION 1: VIEW CONFIGURED SERVICES
   ================================================= */
void view_services()
{
    FILE *file;
    char service[100];

    file = fopen(CONFIG_FILE, "r");

    if (file == NULL)
    {
        printf("Error: Could not open services.conf\n");
        return;
    }

    printf("\n=============================================\n");
    printf("           CONFIGURED SERVICES\n");
    printf("=============================================\n");

    while (fgets(service, sizeof(service), file))
    {
        service[strcspn(service, "\n")] = '\0';

        if (strlen(service) > 0)
            printf("- %s\n", service);
    }

    fclose(file);

    printf("=============================================\n");
}


/* =================================================
   OPTIONS 2, 3, 4: START / STOP / RESTART
   ================================================= */
void control_service(const char *action)
{
    char service[100];
    char command[200];

    printf("\nEnter service name: ");
    scanf("%99s", service);

    snprintf(command,
             sizeof(command),
             "sudo systemctl %s %s",
             action,
             service);

    printf("\nExecuting: systemctl %s %s\n",
           action,
           service);

    system(command);

    printf("Operation completed.\n");
}


/* =================================================
   OPTION 5: CHECK SERVICE STATUS
   ================================================= */
void check_status()
{
    FILE *file;
    char service[100];
    char command[200];

    file = fopen(CONFIG_FILE, "r");

    if (file == NULL)
    {
        printf("Error: Could not open services.conf\n");
        return;
    }

    printf("\n=============================================\n");
    printf("              SERVICE STATUS\n");
    printf("=============================================\n");

    while (fgets(service, sizeof(service), file))
    {
        service[strcspn(service, "\n")] = '\0';

        if (strlen(service) == 0)
            continue;

        printf("\nService: %s\n", service);

        snprintf(command,
                 sizeof(command),
                 "systemctl is-active %s",
                 service);

        system(command);
    }

    fclose(file);

    printf("\n=============================================\n");
}


/* =================================================
   OPTION 6: CPU / MEMORY MONITORING
   ================================================= */
void monitor_resources()
{
    FILE *file;
    char service[100];

    file = fopen(CONFIG_FILE, "r");

    if (file == NULL)
    {
        printf("Error: Could not open services.conf\n");
        return;
    }

    printf("\n====================================================\n");
    printf("              RESOURCE MONITORING\n");
    printf("====================================================\n");

    printf("%-12s %-10s %-8s %-8s %-8s\n",
           "SERVICE",
           "STATUS",
           "PID",
           "CPU%",
           "MEM%");

    printf("----------------------------------------------------\n");

    while (fgets(service, sizeof(service), file))
    {
        char status[30] = "N/A";
        char pid[30] = "0";
        char cpu[30] = "N/A";
        char memory[30] = "N/A";
        char command[300];

        service[strcspn(service, "\n")] = '\0';

        if (strlen(service) == 0)
            continue;


        /* Get status */
        snprintf(command,
                 sizeof(command),
                 "systemctl is-active %s",
                 service);

        FILE *status_pipe = popen(command, "r");

        if (status_pipe != NULL)
        {
            if (fgets(status, sizeof(status), status_pipe))
                status[strcspn(status, "\n")] = '\0';

            pclose(status_pipe);
        }


        /* Get PID */
        snprintf(command,
                 sizeof(command),
                 "systemctl show %s --property=MainPID --value",
                 service);

        FILE *pid_pipe = popen(command, "r");

        if (pid_pipe != NULL)
        {
            if (fgets(pid, sizeof(pid), pid_pipe))
                pid[strcspn(pid, "\n")] = '\0';

            pclose(pid_pipe);
        }


        /* Get CPU and memory */
        if (strcmp(pid, "0") != 0 && strlen(pid) > 0)
        {
            snprintf(command,
                     sizeof(command),
                     "ps -p %s -o %%cpu=,%%mem=",
                     pid);

            FILE *resource_pipe = popen(command, "r");

            if (resource_pipe != NULL)
            {
                char resource[100];

                if (fgets(resource, sizeof(resource), resource_pipe))
                {
                    if (sscanf(resource,
                               "%29s %29s",
                               cpu,
                               memory) != 2)
                    {
                        strcpy(cpu, "N/A");
                        strcpy(memory, "N/A");
                    }
                }

                pclose(resource_pipe);
            }
        }

        printf("%-12s %-10s %-8s %-8s %-8s\n",
               service,
               status,
               pid,
               cpu,
               memory);
    }

    fclose(file);

    printf("====================================================\n");
}


/* =================================================
   OPTION 7: VIEW SERVICE LOGS
   ================================================= */
void view_logs()
{
    char service[100];
    char command[300];

    printf("\nEnter service name: ");
    scanf("%99s", service);

    printf("\n=============================================\n");
    printf("          SERVICE LOGS: %s\n", service);
    printf("=============================================\n");

    snprintf(command,
             sizeof(command),
             "journalctl -u %s --no-pager -n 10",
             service);

    system(command);

    printf("=============================================\n");
}


/* =================================================
   OPTION 8: START AUTOMATIC MONITORING
   ================================================= */
void start_monitoring()
{
    if (monitor_pid > 0)
    {
        if (kill(monitor_pid, 0) == 0)
        {
            printf("\nAutomatic monitoring is already running.\n");
            printf("Monitor PID: %d\n", monitor_pid);
            return;
        }

        monitor_pid = -1;
    }


    monitor_pid = fork();

    if (monitor_pid < 0)
    {
        printf("\nError: Could not create monitoring process.\n");
        monitor_pid = -1;
        return;
    }


    /* Child */
    if (monitor_pid == 0)
    {
        execl("./scripts/monitor.sh",
              "monitor.sh",
              (char *)NULL);

        printf("Error: Could not execute monitor.sh\n");
        exit(1);
    }


    /* Parent */
    printf("\n=============================================\n");
    printf("       AUTOMATIC MONITORING STARTED\n");
    printf("=============================================\n");
    printf("Monitor PID : %d\n", monitor_pid);
    printf("Monitor file: scripts/monitor.sh\n");
    printf("Monitoring is running in background.\n");
    printf("=============================================\n");
}


/* =================================================
   OPTION 9: STOP AUTOMATIC MONITORING
   ================================================= */
void stop_monitoring()
{
    if (monitor_pid <= 0)
    {
        printf("\nAutomatic monitoring is not running.\n");
        return;
    }


    if (kill(monitor_pid, SIGTERM) == 0)
    {
        printf("\n=============================================\n");
        printf("       AUTOMATIC MONITORING STOPPED\n");
        printf("=============================================\n");

        printf("Monitor PID %d has been stopped.\n",
               monitor_pid);

        printf("=============================================\n");

        waitpid(monitor_pid, NULL, 0);

        monitor_pid = -1;
    }
    else
    {
        perror("\nError stopping monitor");
        monitor_pid = -1;
    }
}


/* =================================================
   OPTION 10: SYSTEM INFORMATION
   ================================================= */
void system_information()
{
    printf("\n=============================================\n");
    printf("             SYSTEM INFORMATION\n");
    printf("=============================================\n");

    printf("\nOperating System:\n");
    system("uname -o");

    printf("\nKernel Version:\n");
    system("uname -r");

    printf("\nHostname:\n");
    system("hostname");

    printf("\nSystem Architecture:\n");
    system("uname -m");

    printf("\nSystem Uptime:\n");
    system("uptime -p");

    printf("\nCPU Information:\n");
    system("lscpu | grep 'Model name' | head -1");

    printf("\nMemory Information:\n");
    system("free -h");

    printf("=============================================\n");
}


/* =================================================
   MAIN FUNCTION
   ================================================= */
int main()
{
    int choice;

    while (1)
    {
        printf("\n=============================================\n");
        printf("        LINUX SERVICE SUPERVISOR\n");
        printf("=============================================\n");

        printf("1. View Services\n");
        printf("2. Start Service\n");
        printf("3. Stop Service\n");
        printf("4. Restart Service\n");
        printf("5. Check Service Status\n");
        printf("6. Monitor CPU/Memory\n");
        printf("7. View Service Logs\n");
        printf("8. Start Automatic Monitoring\n");
        printf("9. Stop Automatic Monitoring\n");
        printf("10. System Information\n");
        printf("11. Shutdown Supervisor\n");

        printf("=============================================\n");

        printf("Enter choice: ");
        scanf("%d", &choice);


        switch (choice)
        {
            case 1:
                view_services();
                break;

            case 2:
                control_service("start");
                break;

            case 3:
                control_service("stop");
                break;

            case 4:
                control_service("restart");
                break;

            case 5:
                check_status();
                break;

            case 6:
                monitor_resources();
                break;

            case 7:
                view_logs();
                break;

            case 8:
                start_monitoring();
                break;

            case 9:
                stop_monitoring();
                break;

            case 10:
                system_information();
                break;

            case 11:
                printf("\nShutting down supervisor...\n");

                if (monitor_pid > 0)
                {
                    printf("Stopping automatic monitor...\n");

                    kill(monitor_pid, SIGTERM);

                    waitpid(monitor_pid, NULL, 0);

                    monitor_pid = -1;

                    printf("Automatic monitor stopped.\n");
                }

                printf("Supervisor terminated successfully.\n");

                return 0;

            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    }

    return 0;
}
